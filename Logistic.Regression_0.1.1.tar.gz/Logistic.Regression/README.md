# R_DataSciences_Logistics_Regresion
This is a copy of the final project of the course "STAT 6210: R programming in Data Sciences" at Auburn University.
This project implemented from scratch a Logistic Regression model using R, and packed it into an R package.
Shiny App and Vignettes guidence is available.
